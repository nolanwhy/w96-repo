alert("Thank you for installing this.\nWe have deleted this package and changed the old repo to the new one automatically. Thank you.\nYou might have to reinstall some packages.");
new w96.sys.PkMgr().removePackage({
    "repoId": "main",
    "name": "clouder"
}, (e) => {console.log(e);});
new w96.sys.PkMgr().removePackage({
    "repoId": "main",
    "name": "mP3"
}, (e) => {console.log(e);});
new w96.sys.PkMgr().removePackage({
    "repoId": "main",
    "name": "mrcs"
}, (e) => {console.log(e);});
new w96.sys.PkMgr().removePackage({
    "repoId": "main",
    "name": "obs96"
}, (e) => {console.log(e);});
new w96.sys.PkMgr().removePackage({
    "repoId": "main",
    "name": "tasktop96"
}, (e) => {console.log(e);});
new w96.sys.PkMgr().removePackage({
    "repoId": "main",
    "name": "warning"
}, (e) => {console.log(e);});
let e = async () => {
    let srcs = JSON.parse(await w96.FS.readstr("C:/system/packages/configs/sources.json"));
    srcs.sources.forEach((v, i) => {
        if(v === "https://nolanwhy.github.io/w96-repo/v3") {
            srcs.sources[i] = "https://w96.nolanwh.cf/repo/v3";
        }
    });
    await w96.FS.writestr("C:/system/packages/configs/sources.json", JSON.stringify(srcs));
}
e();