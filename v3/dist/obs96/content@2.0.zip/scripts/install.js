w96.sys.execCmd("OBS96");
alert("Thank you for installing OBS96! Remember, updates are coming!");